<?php
# PILIHAN SATUAN PRODUK / BARANG
$satuan	= array();
$satuan[] = "Kg";
$satuan[] = "Botol";
$satuan[] = "Dos";
$satuan[] = "Karton";
$satuan[] = "Sachet";
$satuan[] = "Bungkus";
$satuan[] = "Lembar";
$satuan[] = "Buah";
$satuan[] = "Unit";
?>